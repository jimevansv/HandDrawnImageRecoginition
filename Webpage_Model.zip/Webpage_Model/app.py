from flask import Flask, render_template, request
import base64

app = Flask(__name__, template_folder='html')
UPLOAD_FOLDER = 'uploads/'
app.secret_key = "$F!@sKpR0jeCt$"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024


def get_items(image):
    with open("images/save_image", "w+") as fp:
        fp.write(image)

    print("IMAGE OBTAINED")

@app.route('/', defaults={'path': 'html'})
@app.route('/upload', methods=['GET', 'POST'])
def upload_file(path):
    image = None
    if request.method == 'POST':
        names = request.get_json()
        if "image" in names:
            image = base64.decodebytes(names['image'])
            get_items(image)

    return render_template('find.html')


@app.route('/found')
def found():
    items = get_items()
    return render_template('found.html', image_names = items)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
